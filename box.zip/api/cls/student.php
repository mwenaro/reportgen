<?php

class Student {

    function __construct() {
        
    }
    function getOne($id) {
        
    }
}