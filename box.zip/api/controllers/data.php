<?php

class Data extends Controller {

    function __construct() {
        parent::__construct();
    }

    function output() {
        
    }

}
