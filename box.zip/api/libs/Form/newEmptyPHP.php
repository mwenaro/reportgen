<?php

$d = array(
    "studentId" => "299",
    "first_name" =>
    "abdalla",
    "middle_name" =>
    "mwero",
    "last_name" =>
    "mangale",
    "dob" =>
    "2018-12-30T21:00:00.000Z"
    , "gen" =>
    "m",
    "religion" =>
    "i",
    "county" =>
    "kwale",
    "subcounty" =>
    NULL,
    "adm" =>
    "1",
    "form" =>
    "3",
    "upi" =>
    NULL,
    "clubs" =>
    NULL,
    "designationId" =>
    NULL,
    "constituency" =>
    NULL,
    "residence" =>
    "kwao",
    "isDeleted" =>
    "0",
    "creatorId" =>
    NULL,
    "doa" =>
    "2018-08-08 18:26:05",
    "dateCreated" =>
    "2018-08-08 18:26:05",
    "dateUpdated" =>
    NULL,
    "updatorId" =>
    NULL,
    "password" =>
    NULL,
    "securityQuiz" =>
    NULL,
    "securityAns" =>
    NULL,
    "name" =>
    "abdalla mwero mangale",
    "ward" =>
    "kasemeni"
);
