<div style="border:80%;height: 400px;background: red;">
    <h2>My App</h2>
</div>

