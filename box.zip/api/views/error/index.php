<div class="w3-container" style="height: min-height:500px;">
    <h3 class="w3-text-red w3-center"> Sorry! <?php echo $this->msg; ?> .....</h3>
    <div class="w3-container w3-center"> <a class="w3-green w3-button w3-text-black" href="<?php echo URL;?>login"><span class="w3-text-white w3-xlarge fa fa-backward"
                ></span> Go Back</a></div>
</div>