(function(app){
   app.component('user',{
//       template:"<div class='w3-red'>Hello I'm user component</div>",
       templateUrl:'http://127.0.0.1:7173/app/components/user/user-view.php',
       controller:'user',
       controllerAs:'user'
          }); 
})(app);


