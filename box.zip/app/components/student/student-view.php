<html>
    <head></head>
    <body>
        <div class="container wrapper"></div>
        <div class="banner" id="my_banner">
         div <label for="" class="mylabel"></label>
        </div>
    </body>
</html>
