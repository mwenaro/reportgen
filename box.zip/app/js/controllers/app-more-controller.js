/*var app = angular.module('myApp', []);*/
(function (app) {
    app.controller('myController', function ($scope) {
        $scope.name = "Jane";
        $scope.age = "36";
    });


})(app);







