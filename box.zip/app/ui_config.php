<?php
$h = [
            'controllers' => [
                'admin',
                'exam',
                'login',
                'logout',
                'student',
                'teacher',
                'user',
                /*                 * *********************
                 * 
                 * to be removed
                 * *** */
                'more',
                'more-ctrls'
            ],
            'services' => [
                'authetication',
                'data',
                'login',
                'session',
                /* To be Romoved */
                'factories',
                'more'
            ],
            'configs' => [
                'more',
                'routes'
            ]
];
