<div class="w3-panel w3-light-gray" style="text-align: center">
    <h2>Password Reset Page</h2>
    <p>Kindly Contact the App Admin for a password reset</p>
</div>