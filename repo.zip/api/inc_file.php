<?php
require_once 'config.php';


require_once  'libs/session' . ".php";
require_once LIBS . '_request' . ".php";
//require_once LIBS . 'database' . ".php";
require_once LIBS . 'controller' . ".php";
//require_once CLS.'super.cls.php';
require_once URL.'api/output/data_configs.php';
require_once 'database.exten.php';

//$db=new Database('sqlite', DB_PATH);

//$db = new SqliteDataCls();
//print_r($db->select("SELECT * FROM students ")->getData());
// echo LIBS . 'Controller' .".php";