_utility.directive('scoreTable',[]);

