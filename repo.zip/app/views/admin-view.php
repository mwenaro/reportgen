<h2>admin</h2>

<div class="w3-container">
<form >
  <div class="form-row">
    <div class="col-md-6 well w3-margin-2" >
        <h3>Name</h3>
    </div>
    <div class="col-md-6 well w3-margin-2">
        <h3>Age</h3>
    </div>
  </div>
</form>
</div>   

