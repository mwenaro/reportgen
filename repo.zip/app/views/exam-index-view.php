<div class="w3-panel w3-yellow">
    <h3 class="w3-center">Hello I'm Index</h3>
</div>